// @flow
import './Chat.css'

import { connect } from 'react-redux'
import * as React from 'react'

import FilterPills from '../FilterPills/FilterPills'

import InputBox from '../InputBox/InputBox'
import Loader from '../Loader/Loader'
import Messages from '../Messages/Messages'
import QuestionsList from '../QuestionsList/QuestionsList'
import config from '../../config'
import UbotHeader from './UbotHeader'


import { mapStateToProps } from './connector'

import { relative } from 'path';

type Props = {
  suggestedQuestions: Array<string>,
  favouriteQuestions: Array<string>,
}
type State = {}

class Chat extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = {
      toggleWindow: true,
      showQuestions: false
    }
    this.toggleQuestionMenuWindow = this.toggleQuestionMenuWindow.bind(this);
    this.setWrapperRef = this.setWrapperRef.bind(this)
    this.handleClickOutside = this.handleClickOutside.bind(this)
  }
  closeWindow() {
    this.setState({
      toggleWindow: !this.state.toggleWindow,

    });
  }

  toggleQuestionMenuWindow() {

    this.setState({
      showQuestions: !this.state.showQuestions,
    });
  }
  componentDidMount() {
    document.addEventListener('mousedown', this.handleClickOutside)
  }

  componentWillUnmount() {
    document.removeEventListener('mousedown', this.handleClickOutside)
  }

  /**
   * Set the wrapper ref
   */
  setWrapperRef(node) {
    this.wrapperRef = node
  }
  handleClickOutside(event) {
    if (this.wrapperRef && !this.wrapperRef.contains(event.target)) {
      this.setState({
        showQuestions: false,
      })
    }
  }
  render(): React.Node {
    return (
      <div className="container-fluid">

        <div className="row chatBot-Height" >

          {/* <Chat toggleQuestionMenu={this.toggleQuestionMenuWindow} /> */}
          <div className="col-12" style={{ paddingLeft: '0', paddingRight: '1px' }}>

            <div className="card" style={{ bottom: '0px', height: '95%', border: 'none' }}> 
              <Loader />
              <div className="messages" id="messages-window" style={{ border: ' 1px solid #004F80', borderBottom: 'none' }}>
                <div className="col-1 p-2 menuIcon" onClick={this.toggleQuestionMenuWindow}><i className="fa fa-bars icon-color" /></div>
                <div className="row" style={{ display: 'inline-block' }}>
                  <div className="questionListPosition" ref={this.setWrapperRef}>
                    {this.state.showQuestions && (<QuestionsList
                      name="Suggested Questions"
                      questions={this.props.suggestedQuestions} />)}

                    {this.state.showQuestions && (<QuestionsList
                      name="Favorite Questions"
                      questions={this.props.favouriteQuestions}
                      removeOption />
                    )}
                  </div>

                </div>
                <Messages />

              </div>

            </div>
            <div className="msgBoxBottom">
              <div> <FilterPills /></div>
              <div><InputBox /></div>
            </div>

          </div>
        </div>

      </div>

    )
  }
}

export default connect(mapStateToProps)(Chat)